package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.media.Image
import android.graphics.Rect

/**
 * Integrates OCR observations with the rules engine.
 * Because OCR colour alone cannot distinguish hearts/diamonds or clubs/spades, and
 * hidden-card counts depend on exact game layout, this adapter refuses to guess suits.
 */
object BoardAnalyzer {
    data class Move(
        val fromX: Float, val fromY: Float,
        val toX: Float, val toY: Float,
        val durationMs: Long = 450L,
        val isTap: Boolean = false
    )
    data class Analysis(val status: String, val proposedMove: Move? = null)

    fun analyze(image: Image, width: Int, height: Int): Analysis {
        val bitmap = try { CardVision.imageToBitmap(image) }
        catch (_: Exception) { return Analysis("تعذر تحويل إطار الشاشة") }
        return try {
            analyze(bitmap)
        } finally {
            bitmap.recycle()
        }
    }

    fun analyze(bitmap: Bitmap): Analysis {
        val observation = try { CardVision.analyze(bitmap) }
        catch (e: Exception) { return Analysis("خطأ في تحليل الصورة: ${e.message ?: "غير معروف"}") }

        val recognized = observation.columns.sumOf { it.visibleCards.size }
        val status = "تم فحص 7 أعمدة؛ كروت مقروءة: $recognized. ${observation.diagnostics}"

        // The current OCR pass can identify rank and red/black ink, but exact suit and
        // face-down-card count are not sufficiently reliable for safe automatic play.
        // Therefore it reports recognition only and does not dispatch a guessed gesture.
        return Analysis("$status — يلزم معايرة أماكن اللوحة وتمييز رمز النوع قبل اللعب التلقائي")
    }
}
