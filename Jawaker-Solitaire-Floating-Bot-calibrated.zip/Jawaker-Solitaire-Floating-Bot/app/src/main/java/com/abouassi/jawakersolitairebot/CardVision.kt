package com.abouassi.jawakersolitairebot

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.media.Image
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/**
 * Screen-to-board adapter for a classic 7-column Klondike layout.
 *
 * IMPORTANT: UI coordinates vary between Jawaker versions, display cutouts and game modes.
 * The normalized anchors below are starting estimates and must be calibrated against
 * screenshots from the exact game screen. This implementation uses OCR on each exposed
 * card's top-left corner and red/black pixel sampling for suit colour; it does not claim
 * perfect suit-symbol classification.
 */
object CardVision {
    data class CardObservation(
        val rank: Int?,
        val suitColor: SolitaireEngine.SuitColor,
        val confidence: Float,
        val bounds: Rect
    )

    // SuitColor is kept separate from exact suit: red/black alone cannot distinguish suits.
    data class ColumnObservation(
        val visibleCards: List<CardObservation>,
        val hiddenCount: Int
    )

    data class BoardObservation(
        val columns: List<ColumnObservation>,
        val foundationRanks: List<Int?>,
        val waste: CardObservation?,
        val stockHasCard: Boolean,
        val diagnostics: String
    )

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    // Calibrated from the supplied Jawaker Solitaire screenshots.
    // The uploaded PNGs are 674x1536; the phone reports 720x1640.
    // Normalized anchors preserve the same geometry at either resolution.
    // Four foundations are on the LEFT, waste is near the RIGHT, stock is far RIGHT.
    private val columnCenters = floatArrayOf(.110f, .250f, .390f, .530f, .670f, .810f, .950f)
    private const val tableauTop = .338f
    private const val cardWidth = .130f
    private const val cardHeight = .195f
    private const val verticalStep = .0415f
    private const val stockX = .950f
    private const val wasteX = .740f
    private const val topY = .285f
    private val foundationXs = floatArrayOf(.110f, .250f, .390f, .530f)

    fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        return Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            .also { padded.recycle() }
    }

    fun analyze(bitmap: Bitmap): BoardObservation {
        val w = bitmap.width
        val h = bitmap.height
        val columns = mutableListOf<ColumnObservation>()
        for (i in 0..6) {
            val xCenter = columnCenters[i] * w
            val x = (xCenter - cardWidth * w / 2).toInt().coerceIn(0, w - 1)
            val cards = mutableListOf<CardObservation>()
            // Each exposed card index begins at a fixed vertical offset in the tableau.
            // Keep the crop narrow and shallow so the next overlapping card does not enter OCR.
            for (depth in 0..12) {
                val y = ((tableauTop + depth * verticalStep) * h).toInt()
                if (y + (cardHeight * h * .24f).toInt() >= h) break
                val rect = Rect(
                    x, y,
                    min(w, x + (cardWidth * w).toInt()),
                    min(h, y + (cardHeight * h).toInt())
                )
                val card = recognizeCard(bitmap, rect)
                if (card.rank != null) cards += card
            }
            val hidden = estimateHiddenBacks(bitmap, x, (tableauTop * h).toInt(),
                min(h, (tableauTop * h).toInt() + (cardHeight * h * 1.8f).toInt()),
                (cardWidth * w).toInt())
            columns += ColumnObservation(cards.distinctBy { it.bounds.top }, hidden)
        }

        val foundations = foundationXs.map { fx ->
            val rect = cardRect(w, h, fx, topY)
            recognizeCard(bitmap, rect).rank
        }
        val waste = recognizeCard(bitmap, cardRect(w, h, wasteX, topY))
        val stockRect = cardRect(w, h, stockX, topY)
        val stockHasCard = estimateStock(bitmap, stockRect)
        return BoardObservation(columns, foundations, waste.takeIf { it.rank != null },
            stockHasCard, "Frame ${w}x${h}; calibrated 7-column/top-row anchors; OCR rank + red/black ink estimate")
    }

    private fun cardRect(w: Int, h: Int, centerX: Float, centerY: Float): Rect {
        val left = (centerX * w - cardWidth * w / 2).toInt().coerceIn(0, w - 1)
        val top = (centerY * h).toInt().coerceIn(0, h - 1)
        return Rect(left, top, min(w, left + (cardWidth * w).toInt()),
            min(h, top + (cardHeight * h).toInt()))
    }

    private fun recognizeCard(source: Bitmap, bounds: Rect): CardObservation {
        val crop = cropCorner(source, bounds)
        val color = classifyColor(crop)
        val latch = CountDownLatch(1)
        var detectedText = ""
        try {
            val input = InputImage.fromBitmap(crop, 0)
            recognizer.process(input)
                .addOnSuccessListener { result -> detectedText = result.text.uppercase() }
                .addOnCompleteListener { latch.countDown() }
            latch.await(450, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {
        } finally {
            crop.recycle()
        }
        val rank = parseRank(detectedText)
        return CardObservation(rank, color, if (rank == null) 0f else .65f, Rect(bounds))
    }

    private fun cropCorner(source: Bitmap, card: Rect): Bitmap {
        // Crop the upper-left index region; OCR sees the rank while colour sampling sees suit ink.
        val left = card.left
        val top = card.top
        val cw = max(1, (card.width() * .52f).toInt())
        val ch = max(1, (card.height() * .24f).toInt())
        return Bitmap.createBitmap(source, left, top, min(cw, source.width - left),
            min(ch, source.height - top))
    }

    private fun parseRank(text: String): Int? {
        val cleaned = text.replace(" ", "").replace("\n", "")
        return when {
            Regex("10|T").containsMatchIn(cleaned) -> 10
            Regex("K").containsMatchIn(cleaned) -> 13
            Regex("Q").containsMatchIn(cleaned) -> 12
            Regex("J").containsMatchIn(cleaned) -> 11
            Regex("A").containsMatchIn(cleaned) -> 1
            else -> cleaned.firstOrNull { it in '2'..'9' }?.digitToInt()
        }
    }

    private fun classifyColor(bitmap: Bitmap): SolitaireEngine.SuitColor {
        var red = 0
        var dark = 0
        val stepX = max(1, bitmap.width / 18)
        val stepY = max(1, bitmap.height / 18)
        for (y in 0 until bitmap.height step stepY) {
            for (x in 0 until bitmap.width step stepX) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                if (r > 110 && r > g * 1.25 && r > b * 1.20) red++
                if (r < 100 && g < 100 && b < 100) dark++
            }
        }
        return if (red > dark) SolitaireEngine.SuitColor.RED else SolitaireEngine.SuitColor.BLACK
    }

    /**
     * Estimates face-down cards from the red horizontal back edges in the supplied layout.
     * This is intentionally a conservative visual estimate, not a guaranteed card count.
     */
    private fun estimateHiddenBacks(bitmap: Bitmap, left: Int, top: Int, bottom: Int, width: Int): Int {
        val right = min(bitmap.width, left + width)
        if (right <= left || bottom <= top) return 0
        val rowFlags = BooleanArray(bottom - top)
        for (y in top until bottom) {
            var red = 0
            var sampled = 0
            for (x in left + width / 8 until min(right, left + width * 7 / 8) step max(1, width / 36)) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                if (r > 75 && r > g * 1.28 && r > b * 1.18) red++
                sampled++
            }
            rowFlags[y - top] = sampled > 0 && red.toFloat() / sampled >= .38f
        }
        var bands = 0
        var inBand = false
        var bandRows = 0
        for (flag in rowFlags) {
            if (flag) {
                bandRows++
                if (!inBand) inBand = true
            } else if (inBand) {
                if (bandRows >= 2) bands++
                inBand = false
                bandRows = 0
            }
        }
        if (inBand && bandRows >= 2) bands++
        // The visible card face is not a red back; cap noisy detections.
        return bands.coerceIn(0, 12)
    }

    private fun estimateStock(bitmap: Bitmap, rect: Rect): Boolean {
        // Detect non-background card pixels; exact stock-empty artwork is game-specific.
        var contrast = 0
        val bg = bitmap.getPixel(rect.centerX().coerceIn(0, bitmap.width - 1),
            rect.centerY().coerceIn(0, bitmap.height - 1))
        for (y in rect.top until rect.bottom step max(1, rect.height() / 12)) {
            for (x in rect.left until rect.right step max(1, rect.width() / 12)) {
                val c = bitmap.getPixel(x, y)
                val d = kotlin.math.abs(Color.red(c) - Color.red(bg)) +
                    kotlin.math.abs(Color.green(c) - Color.green(bg)) +
                    kotlin.math.abs(Color.blue(c) - Color.blue(bg))
                if (d > 70) contrast++
            }
        }
        return contrast > 5
    }
}

/** Red/black classification only; exact suit requires a trained/template suit-symbol recognizer. */
