package com.abouassi.jawakersolitairebot

/**
 * Klondike move planner. The recognizer supplies only visible cards; face-down counts
 * and stock state are maintained separately. All indices are zero-based.
 */
object SolitaireEngine {
    enum class Suit { HEARTS, DIAMONDS, CLUBS, SPADES }
    enum class SuitColor { RED, BLACK }
    enum class Zone { TABLEAU, FOUNDATION, WASTE, STOCK }

    data class Card(val rank: Int, val suit: Suit) {
        init { require(rank in 1..13) }
        val isRed: Boolean get() = suit == Suit.HEARTS || suit == Suit.DIAMONDS
        fun canStackOn(other: Card): Boolean =
            isRed != other.isRed && rank == other.rank - 1
    }

    data class TableauColumn(
        val faceUp: List<Card>,
        val faceDownCount: Int
    )

    data class Board(
        val columns: List<TableauColumn>,
        val foundations: Map<Suit, Int>,
        val waste: Card?,
        val stockAvailable: Boolean
    )

    data class Move(
        val fromZone: Zone,
        val fromColumn: Int = -1,
        val cardIndex: Int = -1,
        val toZone: Zone,
        val toColumn: Int = -1,
        val suit: Suit? = null,
        val reason: String,
        val score: Int
    )

    fun chooseMove(board: Board): Move? {
        if (board.columns.size != 7) return null

        val candidates = mutableListOf<Move>()

        // 1) Foundation moves from tableau or waste.
        board.columns.forEachIndexed { colIndex, col ->
            col.faceUp.forEachIndexed { cardIndex, card ->
                val isTop = cardIndex == col.faceUp.lastIndex
                val exposed = isTop && col.faceDownCount > 0
                if (isTop && canMoveToFoundation(card, board)) {
                    candidates += Move(Zone.TABLEAU, colIndex, cardIndex, Zone.FOUNDATION,
                        suit = card.suit, reason = "نقل إلى الأساس", score = 100 + if (exposed) 35 else 0)
                }
            }
        }
        board.waste?.let { card ->
            if (canMoveToFoundation(card, board)) {
                candidates += Move(Zone.WASTE, toZone = Zone.FOUNDATION, suit = card.suit,
                    reason = "نقل كرت المخلفات إلى الأساس", score = 110)
            }
        }

        // 2) Tableau-to-tableau moves. Move a suffix, not just one card.
        board.columns.forEachIndexed { fromIndex, source ->
            source.faceUp.forEachIndexed { cardIndex, movingCard ->
                if (cardIndex == 0 && source.faceDownCount == 0 && source.faceUp.size == 1 &&
                    movingCard.rank == 13) {
                    // A king can occupy an empty column; handled below.
                }
                val suffix = source.faceUp.drop(cardIndex)
                if (suffix.isEmpty()) return@forEachIndexed
                val isExposingHidden = cardIndex == 0 && source.faceDownCount > 0
                board.columns.forEachIndexed targetLoop@{ toIndex, target ->
                    if (fromIndex == toIndex) return@targetLoop
                    val top = target.faceUp.lastOrNull()
                    val legal = if (top == null) movingCard.rank == 13
                                else movingCard.canStackOn(top)
                    if (legal) {
                        val score = 55 + if (isExposingHidden) 45 else 0 +
                            if (target.faceUp.isEmpty()) 8 else 0
                        candidates += Move(Zone.TABLEAU, fromIndex, cardIndex, Zone.TABLEAU,
                            toColumn = toIndex,
                            reason = if (isExposingHidden) "كشف كرت مخفي" else "ترتيب الأعمدة",
                            score = score)
                    }
                }
            }
        }

        // Waste card may be moved onto a tableau column.
        board.waste?.let { card ->
            board.columns.forEachIndexed { toIndex, target ->
                val top = target.faceUp.lastOrNull()
                val legal = if (top == null) card.rank == 13 else card.canStackOn(top)
                if (legal) candidates += Move(Zone.WASTE, toZone = Zone.TABLEAU,
                    toColumn = toIndex, reason = "نقل من المخلفات إلى عمود", score = 65)
            }
        }

        // 3) Prefer any valid board move. 4) Draw only if no tableau/foundation move exists.
        return candidates.maxByOrNull { it.score } ?: if (board.stockAvailable)
            Move(Zone.STOCK, toZone = Zone.WASTE, reason = "سحب كرت جديد", score = 1)
        else null
    }

    private fun canMoveToFoundation(card: Card, board: Board): Boolean {
        val current = board.foundations[card.suit] ?: 0
        return card.rank == current + 1
    }
}
