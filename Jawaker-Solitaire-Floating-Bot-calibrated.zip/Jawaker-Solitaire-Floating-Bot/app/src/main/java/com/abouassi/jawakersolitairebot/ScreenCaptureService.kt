package com.abouassi.jawakersolitairebot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    @Volatile private var botRunning = false
    private var lastAnalysisAt = 0L

    private val toggleReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            botRunning = intent?.getBooleanExtra(EXTRA_RUNNING, false) ?: false
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val filter = IntentFilter(ACTION_SET_RUNNING)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(toggleReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(toggleReceiver, filter)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        if (data != null && projection == null) startProjection(resultCode, data)
        return START_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        worker = HandlerThread("JawakerFrameAnalyzer").also { it.start() }
        handler = Handler(worker!!.looper)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            var image: Image? = null
            try {
                image = reader.acquireLatestImage()
                if (image != null) {
                    // Frame data is captured here. Recognition is intentionally isolated in BoardAnalyzer.
                    if (botRunning && System.currentTimeMillis() - lastAnalysisAt > 500) {
                        lastAnalysisAt = System.currentTimeMillis()
                        val result = BoardAnalyzer.analyze(image, width, height)
                        sendBroadcast(Intent(ACTION_ANALYSIS_STATUS).setPackage(packageName)
                            .putExtra(EXTRA_STATUS, result.status))
                        // No gesture is issued until a verified card and legal move are identified.
                        result.proposedMove?.let { move ->
                            if (BotAccessibilityService.isEnabled()) {
                                BotAccessibilityService.dispatchDrag(
                                    move.fromX, move.fromY, move.toX, move.toY, move.durationMs
                                )
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, handler)

        virtualDisplay = projection?.createVirtualDisplay(
            "JawakerScreenCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Jawaker Bot Capture",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jawaker Solitaire Floating Bot")
            .setContentText("خدمة التقاط الشاشة نشطة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        runCatching { unregisterReceiver(toggleReceiver) }
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        worker?.quitSafely()
        projection = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "capture_result_code"
        const val EXTRA_RESULT_DATA = "capture_result_data"
        const val ACTION_SET_RUNNING = "com.abouassi.jawakersolitairebot.SET_RUNNING"
        const val ACTION_ANALYSIS_STATUS = "com.abouassi.jawakersolitairebot.ANALYSIS_STATUS"
        const val EXTRA_RUNNING = "running"
        const val EXTRA_STATUS = "status"
        private const val CHANNEL_ID = "jawaker_capture"
        private const val NOTIFICATION_ID = 701
    }
}
